# models/__init__.py
from . import branch_product
from . import branch
from . import supply_request
from . import supply_request_line
from . import res_users_extension
from . import product_extension
from . import supply_log
from . import supply_unit
